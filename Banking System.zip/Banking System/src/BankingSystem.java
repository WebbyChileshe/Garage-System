import java.util.Scanner;
public class BankingSystem {
    static double balance = 0.00;
    static double amount = 0.00;

    public static void checkBalance() {
        System.out.println("Your Current Balance is K" + balance);
        System.out.println();
    }

    public static void deposit() {
        Scanner input = new Scanner(System.in);
            System.out.println("Enter the Amount to Deposit: ");
            amount = input.nextDouble();
        balance += amount;
        System.out.println("Amount has been successfully Deposited to your Account");
        checkBalance();
    }

    public static void withdraw() {
        Scanner enterAmount = new Scanner(System.in);
            System.out.println("Enter the Amount to Withdraw: ");
            amount = enterAmount.nextDouble();
        if (amount > balance) {
            System.out.println("Insufficient Balance");
        } else {
            balance -= amount;
            System.out.println("You have Withdrawn: " + amount + " from your Account: ");
        }
        checkBalance();
    }

    public static void exit() {
        System.out.println("Thank You!");
    }

    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {
            int choice = 0;
            while (choice != 4) {
                System.out.println("************ OPTIONS ***************");
                System.out.println("1. Check your Balance           ****");
                System.out.println("2. Deposit                      ****");
                System.out.println("3. Withdraw                     ****");
                System.out.println("4. Exit                         ****");
                System.out.println("************************************");
                System.out.println();
                System.out.println("Please Enter an Option from Above to Proceed!!!");
                choice = input.nextInt();

                switch (choice) {
                    case 1 -> checkBalance();
                    case 2 -> deposit();
                    case 3 -> withdraw();
                    case 4 -> exit();
                }

            }
        }
    }
}
