-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2024 at 08:38 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `garagedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CustomerID` int(11) NOT NULL,
  `CustomerName` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Phone_Number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustomerID`, `CustomerName`, `Address`, `Phone_Number`) VALUES
(1, 'Richardson Saiman', 'Lusaka JohnLaing', '94358439'),
(2, 'Joseph Banda', 'Makeni #222', '92849287'),
(3, 'James Sakala', 'Kansenshi, Ndola', '09977773337'),
(5, 'Misheck Chileshe', 'Kabwe Makululu', '0234675876'),
(6, 'Mapalo Musonda', 'Kabwe Mine Area', '0234675876');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Employee_id` int(11) NOT NULL,
  `Employee_Name` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Outlet_Name` varchar(255) DEFAULT NULL,
  `Position` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Employee_id`, `Employee_Name`, `Email`, `Password`, `Outlet_Name`, `Position`) VALUES
(4, 'Gilbert Mulenga', 'mulenga@gmail.com', 'mulenga', 'Mukuyu Mall', 'Staff'),
(5, 'Kelly Chabu', 'kelly@gmail.com', 'kelly', 'Mukuyu Mall', 'Staff'),
(6, 'Mwansa Zimba ', 'zimba@gmail.com', 'zimba', 'Mukuyu Mall', 'Staff'),
(8, 'Webby Chileshe', 'webbychileshe27@gmail.com', 'admin', 'Mukuyu Mall', 'Admin'),
(13, 'Faith Kafwimbi', 'kafwimbifaith7@gmail.com', 'faith1234', 'Mukuyu Mall', 'warehouse');

-- --------------------------------------------------------

--
-- Table structure for table `employee_outlet`
--

CREATE TABLE `employee_outlet` (
  `Employee_id` int(11) NOT NULL,
  `Outlet_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `employee_warehouse`
--

CREATE TABLE `employee_warehouse` (
  `Employee_id` int(11) NOT NULL,
  `WarehouseID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderID` int(11) NOT NULL,
  `Stock_Name` varchar(255) DEFAULT NULL,
  `Price` double(10,2) DEFAULT NULL,
  `Quantity` varchar(255) DEFAULT NULL,
  `Discount` double(10,2) NOT NULL,
  `Outlet_Name` varchar(255) DEFAULT NULL,
  `Order_Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderID`, `Stock_Name`, `Price`, `Quantity`, `Discount`, `Outlet_Name`, `Order_Date`) VALUES
(1, 'Car Chair', 200.00, '100', 5.00, 'Mukuyu Mall', '2024-05-09'),
(2, 'Car Chair', 200.00, '90', 5.00, 'Mukuyu Mall', '2024-05-09'),
(3, 'Car Chair', 200.00, '5', 10.00, 'Mukuyu Mall', '2024-05-09'),
(4, 'Car Chair', 200.00, '5', 5.00, 'Mukuyu Mall', '2024-05-09'),
(5, 'Side Mirrors', 250.00, '0', 10.00, 'Mukuyu Mall', '2024-05-09'),
(6, 'Side Mirrors', 250.00, '0', 10.00, 'Mukuyu Mall', '2024-05-09'),
(7, 'Side Mirrors', 250.00, '0', 10.00, 'Mukuyu Mall', '2024-05-09'),
(8, 'Side Mirrors', 250.00, '0', 10.00, 'Mukuyu Mall', '2024-05-09'),
(10, 'Tires', 500.00, '100', 0.00, 'Mukuyu Mall', '2024-05-09'),
(11, 'Laptop', 4500.00, '15', 50.00, 'Mukuyu Mall', '2024-05-22'),
(12, 'Chira Zm', 30.00, '135', 50.00, 'Mukuyu Mall', '2024-05-22');

-- --------------------------------------------------------

--
-- Table structure for table `order_part`
--

CREATE TABLE `order_part` (
  `OrderID` int(11) NOT NULL,
  `PartID` int(11) NOT NULL,
  `Quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `outlet`
--

CREATE TABLE `outlet` (
  `Outlet_ID` int(11) NOT NULL,
  `Outlet_Name` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `outlet`
--

INSERT INTO `outlet` (`Outlet_ID`, `Outlet_Name`, `Address`) VALUES
(1, 'Mukuyu Mall', 'Kabwe Town Shop #107'),
(5, 'Kabwe Outlet', 'plot 222'),
(6, 'Ndola Outlet', 'Along Great North Road');

-- --------------------------------------------------------

--
-- Table structure for table `part`
--

CREATE TABLE `part` (
  `PartID` int(11) NOT NULL,
  `Part_Name` varchar(255) DEFAULT NULL,
  `Price` double(10,2) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `Outlet_Name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Payment_id` int(11) NOT NULL,
  `CustomerName` varchar(255) DEFAULT NULL,
  `Stock_Name` varchar(255) DEFAULT NULL,
  `Price` double(10,2) DEFAULT NULL,
  `Quantity` int(11) NOT NULL,
  `Date_Sold` date DEFAULT NULL,
  `Outlet_Name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Payment_id`, `CustomerName`, `Stock_Name`, `Price`, `Quantity`, `Date_Sold`, `Outlet_Name`) VALUES
(1, 'Richardson Saiman', 'Car Chair', 200.00, 0, '2024-05-09', 'Mukuyu Mall'),
(2, 'Richardson Saiman', 'Car Chair', 200.00, 0, '2024-05-09', 'Mukuyu Mall'),
(3, 'Richardson Saiman', 'Car Chair', 200.00, 0, '2024-05-09', 'Mukuyu Mall'),
(4, 'Richardson Saiman', 'Tires', 500.00, 0, '2024-05-09', 'Mukuyu Mall'),
(5, 'Joseph Banda', 'Tires', 500.00, 0, '2024-05-10', 'Mukuyu Mall'),
(6, 'Richardson Saiman', 'Tires', 500.00, 1, '2024-05-10', 'Mukuyu Mall'),
(7, 'Richardson Saiman', 'Car Chair', 200.00, 15, '2024-05-10', 'Mukuyu Mall'),
(8, 'Joseph Banda', 'Tires', 500.00, 5, '2024-05-10', 'Mukuyu Mall'),
(9, 'James Sakala', 'Tires', 500.00, 1, '2024-05-11', 'Mukuyu Mall'),
(10, 'Richardson Saiman', 'Tires', 500.00, 5, '2024-05-16', 'Mukuyu Mall'),
(11, 'Misheck Chileshe', 'Tires', 500.00, 1, '2024-05-22', 'Mukuyu Mall'),
(12, 'Mapalo Musonda', 'Car Chair', 200.00, 1, '2024-05-22', 'Mukuyu Mall'),
(13, 'Mapalo Musonda', 'Car Chair', 200.00, 1, '2024-05-22', 'Mukuyu Mall'),
(14, 'Misheck Chileshe', 'Car Chair', 200.00, 1, '2024-05-24', 'Mukuyu Mall');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `StockID` int(11) NOT NULL,
  `Stock_Name` varchar(255) DEFAULT NULL,
  `Price` double(10,2) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Discount` double(10,2) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`StockID`, `Stock_Name`, `Price`, `Quantity`, `Discount`, `Description`) VALUES
(1, 'Car Chair', 200.00, 70, 5.00, ''),
(2, 'Side Mirrors', 250.00, 95, 0.00, ''),
(3, 'Tires', 500.00, 4800, 0.00, ''),
(4, 'Brakes', 200.00, 100, 0.00, ''),
(5, 'Gas Pipe', 50.00, 100, 0.00, ''),
(6, 'Motor', 15000.00, 500, 50.00, ''),
(7, 'ToolBox ', 1000.00, 500, 5.00, ''),
(8, 'Valves', 50.00, 100, 0.00, ''),
(9, 'Meter Box', 500.00, 232, 0.00, 'All in One'),
(10, 'Chira Zm', 30.00, 0, 50.00, 'Chira Zm is a woman in MU'),
(11, 'Laptop', 4500.00, 0, 50.00, 'bluh buh bluh blhu');

-- --------------------------------------------------------

--
-- Table structure for table `stock_part`
--

CREATE TABLE `stock_part` (
  `StockID` int(11) NOT NULL,
  `PartID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE `warehouse` (
  `WarehouseID` int(11) NOT NULL,
  `WarehouseName` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`WarehouseID`, `WarehouseName`, `Address`) VALUES
(1, 'Lusaka Central Warehouse', 'Lusaka Industrial Area #101011');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CustomerID`),
  ADD UNIQUE KEY `CustomerName` (`CustomerName`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Employee_id`),
  ADD KEY `Outlet_Name` (`Outlet_Name`);

--
-- Indexes for table `employee_outlet`
--
ALTER TABLE `employee_outlet`
  ADD PRIMARY KEY (`Employee_id`,`Outlet_ID`),
  ADD KEY `Outlet_ID` (`Outlet_ID`);

--
-- Indexes for table `employee_warehouse`
--
ALTER TABLE `employee_warehouse`
  ADD PRIMARY KEY (`Employee_id`,`WarehouseID`),
  ADD KEY `WarehouseID` (`WarehouseID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `Stock_Name` (`Stock_Name`),
  ADD KEY `Outlet_Name` (`Outlet_Name`);

--
-- Indexes for table `order_part`
--
ALTER TABLE `order_part`
  ADD PRIMARY KEY (`OrderID`,`PartID`),
  ADD KEY `PartID` (`PartID`);

--
-- Indexes for table `outlet`
--
ALTER TABLE `outlet`
  ADD PRIMARY KEY (`Outlet_ID`),
  ADD UNIQUE KEY `Outlet_Name` (`Outlet_Name`);

--
-- Indexes for table `part`
--
ALTER TABLE `part`
  ADD PRIMARY KEY (`PartID`),
  ADD UNIQUE KEY `Part_Name` (`Part_Name`),
  ADD KEY `Outlet_Name` (`Outlet_Name`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Payment_id`),
  ADD KEY `Stock_Name` (`Stock_Name`),
  ADD KEY `CustomerName` (`CustomerName`),
  ADD KEY `Outlet_Name` (`Outlet_Name`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`StockID`),
  ADD UNIQUE KEY `Stock_Name` (`Stock_Name`);

--
-- Indexes for table `stock_part`
--
ALTER TABLE `stock_part`
  ADD PRIMARY KEY (`StockID`,`PartID`),
  ADD KEY `PartID` (`PartID`);

--
-- Indexes for table `warehouse`
--
ALTER TABLE `warehouse`
  ADD PRIMARY KEY (`WarehouseID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `CustomerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `Employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OrderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `outlet`
--
ALTER TABLE `outlet`
  MODIFY `Outlet_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `part`
--
ALTER TABLE `part`
  MODIFY `PartID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `Payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `StockID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `warehouse`
--
ALTER TABLE `warehouse`
  MODIFY `WarehouseID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`Outlet_Name`) REFERENCES `outlet` (`Outlet_Name`);

--
-- Constraints for table `employee_outlet`
--
ALTER TABLE `employee_outlet`
  ADD CONSTRAINT `employee_outlet_ibfk_1` FOREIGN KEY (`Employee_id`) REFERENCES `employee` (`Employee_id`),
  ADD CONSTRAINT `employee_outlet_ibfk_2` FOREIGN KEY (`Outlet_ID`) REFERENCES `outlet` (`Outlet_ID`);

--
-- Constraints for table `employee_warehouse`
--
ALTER TABLE `employee_warehouse`
  ADD CONSTRAINT `employee_warehouse_ibfk_1` FOREIGN KEY (`Employee_id`) REFERENCES `employee` (`Employee_id`),
  ADD CONSTRAINT `employee_warehouse_ibfk_2` FOREIGN KEY (`WarehouseID`) REFERENCES `warehouse` (`WarehouseID`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`Stock_Name`) REFERENCES `stock` (`Stock_Name`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`Outlet_Name`) REFERENCES `outlet` (`Outlet_Name`);

--
-- Constraints for table `order_part`
--
ALTER TABLE `order_part`
  ADD CONSTRAINT `order_part_ibfk_1` FOREIGN KEY (`OrderID`) REFERENCES `orders` (`OrderID`),
  ADD CONSTRAINT `order_part_ibfk_2` FOREIGN KEY (`PartID`) REFERENCES `part` (`PartID`);

--
-- Constraints for table `part`
--
ALTER TABLE `part`
  ADD CONSTRAINT `part_ibfk_1` FOREIGN KEY (`Outlet_Name`) REFERENCES `outlet` (`Outlet_Name`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`Stock_Name`) REFERENCES `stock` (`Stock_Name`),
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`CustomerName`) REFERENCES `customer` (`CustomerName`),
  ADD CONSTRAINT `payment_ibfk_3` FOREIGN KEY (`Outlet_Name`) REFERENCES `outlet` (`Outlet_Name`);

--
-- Constraints for table `stock_part`
--
ALTER TABLE `stock_part`
  ADD CONSTRAINT `stock_part_ibfk_1` FOREIGN KEY (`StockID`) REFERENCES `stock` (`StockID`),
  ADD CONSTRAINT `stock_part_ibfk_2` FOREIGN KEY (`PartID`) REFERENCES `part` (`PartID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
