<?php
include('includes/header.php'); 
include('Staff_navbar.php');
include('scripts.php');

$query = "SELECT * FROM stock";
$result = mysqli_query($db, $query);
?>


<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Stock</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="scripts.php" method="POST">

        <div class="modal-body">

            <div class="form-group">
                <label>Product Name</label>
                <input type="text" name="product_name" class="form-control mb-1" placeholder="Select Customer">
            </div>

            <div class="form-group">
                <label>Price</label>
                <input type="text" name="price" class="form-control" placeholder="enter price">
            </div>
            <div class="form-group">
                <label>Quantity</label>
                <input type="text" name="quantity" class="form-control" placeholder="quantity">
            </div>
            <div class="form-group">
                <label>Discount</label>
                <input type="text" name="discount" class="form-control" placeholder="discount">
            </div>
            <div class="form-group">
                <label>Description</label>
                <input type="text" name="description" class="form-control" placeholder="description">
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="Stock_btn" class="btn btn-primary">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>


<div class="container-fluid">
<div class="card shadow mb-4">
  <div class="card-header py-4">
   <h2 class="display-6 text-center">LUSAKA CENTRAL WAREHOUSE</h2>
    <h2 class="display-6 text-center">IN STOCK</h2>
   
    <h6 class="ml-3 m-0 font-weight-bold row ">
     <a class="link l-20" href="warehouse.php">
            <button type="button" class="btn btn-danger pull-left mr-2">BACK</button></a>
            <button type="button" class="btn btn-secondary pull-right mr-2" data-toggle="modal" data-target="#addadminprofile">
              Add Stock
            </button>
            <a class="link l-20" href="warehouse.php">
            <button type="button" class="btn btn-primary">Despatch Products</button></a>
    </h6>
  </div>

  <div class="card-body">
      <table class="table table-bordered text-center text-dark">
          <tr>
            <th>Product Name</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Discount</th>
            <th>Description</th>
          
          </tr>

              <tr>
            <?php
              while($row = mysqli_fetch_assoc($result))
              {
            ?>
            <td><?php echo $row['Stock_Name']?></td>
            <td><?php echo $row['Price']?></td>
            <td><?php echo $row['Quantity']?></td>
            <td><?php echo $row['Discount']?></td>
            <td><?php echo $row['Description']?></td>
          
              </tr>
            <?php
              }
            ?>
          </tr>
      </table>
    </div>
  </div>
</div>
</div>
</div>