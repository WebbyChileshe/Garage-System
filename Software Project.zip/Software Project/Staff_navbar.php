
<?php
include('scripts.php'); 
?>     
      <div id="content">
        <nav class="bg-success topbar mb-2 h-5 static-top">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
               <h1 class="display-2 mb-0 text-center text-white-400"></h1>          
          <ul class="navbar-nav ml-auto">
            </li>
          </ul>
          </div>
        </nav>

        <!-- #region --
        <div class=" ml-auto">
        <div class=" dropdown no-arrow">
  <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class=" text-gray-600 pull-center"><button type="button" class="btn btn-success">Logout</button>
    </span>
  </a>


<!-- Nav Item - User Information -->

  <!-- Dropdown - User Information --
  <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
      <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
      Logout
    </a>
    
  </div>
</div>
</div>
</nav>
<!-- Logout Modal-->

<ul class="accordion" id="accordionSidebar">